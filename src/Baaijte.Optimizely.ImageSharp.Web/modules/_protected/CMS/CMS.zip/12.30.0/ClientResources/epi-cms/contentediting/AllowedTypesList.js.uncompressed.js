﻿define("epi-cms/contentediting/AllowedTypesList", [
    // dojo
    "require",
    "dojo/_base/declare",
    "dojo/dom-class",

    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",

    // epi
    "epi/shell/TypeDescriptorManager",

    // resources
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentreferencelisteditor.restriction"
], function (
    // dojo
    moduleRequire,
    declare,
    domClass,

    // dijit
    _TemplatedMixin,
    _WidgetBase,

    // epi
    TypeDescriptorManager,

    // resources
    resources) {

    return declare([_WidgetBase, _TemplatedMixin], {
        // tags:
        //      internal

        // defaultAllowedTypedList: [public] String[]
        //    The default allowed types list
        templateString: "<div data-dojo-attach-point=\"restrictionInfo\"></div>",
        defaultAllowedTypes: ["episerver.core.icontentdata", "episerver.core.icontent"],
        postMixInProperties: function () {
            this.inherited(arguments);
            this.resources = resources;
        },
        startup: function () {
            if (!this.domNode) {
                return;
            }

            moduleRequire(
                [
                    "epi-cms-react/components/allowed-types-list-widget", "xstyle/css!epi-cms-react/components/allowed-types-list-widget.css"
                ],
                function (AllowedTypesList) {
                    if (!this.restrictionInfo) {
                        return;
                    }
                    var allowedTypesListWidget = new AllowedTypesList({
                        allowedTypes: this.allowedTypes,
                        restrictedTypes: this.restrictedTypes,
                        defaultAllowedTypes: this.defaultAllowedTypes,
                        resources: this.resources
                    });
                    allowedTypesListWidget.placeAt(this.restrictionInfo);
                    this.own(allowedTypesListWidget);
                }.bind(this));
        }
    });
});
